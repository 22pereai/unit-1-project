def display_menu():
    print("The Wizard Inventory program")
    print(" ")
    print("COMMAND MENU")
    print("show - Show all items")
    print("grab - Grab an item")
    print("edit - Modify an item")
    print("drop - Drop an item")
    print("exit - Exit program")
    print()

def show(inventory):
    if len(inventory) == 0:
        print("Your inventory is empty.\n")
        return
    else:
        i = 1
        for item in inventory:
            row = item
            print(str(i) + ". " + row[0] + " (" + str(row[1]) + ")", "@ $" + str(row[2]))
            i += 1
        print()

def main():
    inventory_list = ["wooden staff", "wizard hat", "cloth shoes"]
if __name__ == "__main__":
    main()