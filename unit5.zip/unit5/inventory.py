def display_menu():
    print("The Wizard Inventory program")
    print(" ")
    print("COMMAND MENU")
    print("show - Show all items")
    print("grab - Grab an item")
    print("edit - Modify an item")
    print("drop - Drop an item")
    print("exit - Exit program")
    print()

def show(inventory):
    if len(inventory) == 0:
        print("Your inventory is empty.\n")
        return
    else:
        i = 1
        for item in inventory:
            print(str(i) + ". " + item)
            i += 1
        print()

def grab(inventory):
    if len(inventory) >= 4:
        print("You can't carry any more items. Drop something first.\n")
    else:
        item = str(input("Name: "))
        inventory.append(item)
        print(item + " was added.\n")
        
def edit(inventory):
    number = int(input("Number: "))
    if number < 1 or number > len(inventory):
        print("Invalid item number.\n")
    else:
        number = number - 1
        inventory[number] = str(input("Updated Name: "))
        print("Item number", (number + 1), "was updated.")

def drop(inventory):
    number = int(input("Number: "))
    if number < 1 or number > len(inventory):
        print("Invalid item number.\n")
    else:
        item = inventory.pop(number-1)
        print(item + " was dropped.\n")

def main():
    inventory = ["wooden staff", "wizard hat", "cloth shoes"]

    display_menu()
    while True:        
        command = input("Command: ")
        if command == "show":
            show(inventory)
        elif command == "grab":
            grab(inventory)
        elif command == "edit":
            edit(inventory)
        elif command == "drop":
            drop(inventory)
        elif command == "exit":
            break
        else:
            print("Not a valid command. Please try again.\n")
    print("Bye!")

if __name__ == "__main__":
    main()